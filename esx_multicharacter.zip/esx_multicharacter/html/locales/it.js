const translate = new Object();

translate.name = 'Nome';
translate.job = 'Lavoro Principale';
translate.job2 = 'Lavoro Secondario';
translate.bank = 'Banca';
translate.money = 'Contante';
translate.gender = 'Sesso';
translate.dob = 'Data di nascita';