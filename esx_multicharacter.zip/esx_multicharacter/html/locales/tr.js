const translate = new Object();

translate.name = "İsim";
translate.job = "Meslek";
translate.bank = "Banka";
translate.money = "Nakit";
translate.gender = "Cinsiyet";
translate.dob = "Doğum Tarihi";
