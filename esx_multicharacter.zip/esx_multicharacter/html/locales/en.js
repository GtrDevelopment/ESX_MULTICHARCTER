const translate = new Object();

translate.name = "Nome";
translate.job = "Lavoro";
translate.bank = "Banca";
translate.money = "Contanti";
translate.gender = "Sesso";
translate.dob = "Data di nascita";
